module.exports = {
  
        name: 'loop',
        aliases: ["repeat"],
        category: "music",
        description: 'Repeats all songs in the queue',
        usage: " ",
        accessableby: "everyone",
    run: async (bot, message, args, ops) => {
        const { channel } = message.member.voice;
        if (!channel) return message.channel.send('Я\'извиняюсь но надо быть в голосовом что-бы зациклить музыку');
        const serverQueue = ops.queue.get(message.guild.id);
    try {
        if (!serverQueue) return message.channel.send('There is nothing playing.');
        if (message.guild.me.voice.channel !== message.member.voice.channel) {
            return message.channel.send("Вы должны быть на одном канале с ботом! ");
        }
        if (!serverQueue.loop) {
            serverQueue.loop = true;
            return message.channel.send('Повтор очереди включен.');
        } else {
            serverQueue.loop = false;
            return message.channel.send('Повтор очереди выключен.');
        }
      } catch {
          serverQueue.connection.dispatcher.end();
          await channel.leave();
          return message.channel.send(" Что-то пошло не так. Пожалуйста, попытайтесь еще раз! ");
      }
    }
};
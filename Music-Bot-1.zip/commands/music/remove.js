module.exports = {

        name: "remove",
        aliases: ["rs"],
        category: "music",
        description: "Remove Song In A Queue!",
        usage: "[song number]",
        acessableby: "everyone",
    run: async (bot, message, args, ops) => {
        if (!args[0]) return message.channel.send("**Введите номер песни которую хотите удалить из очереди! :vv: **")

        const { channel } = message.member.voice;
        if (!channel) return message.channel.send('Я\'извиняюсь, но вам нужно быть на голосовом канале, чтобы удалить определенный номер песни!');
        if (message.guild.me.voice.channel !== message.member.voice.channel) {
            return message.channel.send("**Вы должны быть на одном канале с ботом!**");
        };
        const serverQueue = ops.queue.get(message.guild.id);
        if (!serverQueue) return message.channel.send('❌ **Ничего не играет на этом сервере**');
      try {
        if (args[0] < 1 && args[0] >= serverQueue.songs.length) {
            return message.channel.send('**Пожалуйста, введите действительный номер песни!**');
        }
        serverQueue.songs.splice(args[0] - 1, 1);
        return message.channel.send(`Удален номер песни ${args[0]} из очереди`);
      } catch {
          serverQueue.connection.dispatcher.end();
          return message.channel.send("**Something Went Wrong!**")
      }
    }
};
module.exports = {
        name: 'skip',
        description: 'Пропустить.',
        category: "music",
        aliases: ["s"],
        usage: " ",
        accessableby: "everyone",
    run: async (bot, message, args, ops) => {
        const { channel } = message.member.voice;
        if (!channel) return message.channel.send('Я извиняюсь, но вы должны быть в голосовом канале, чтобы пропустить музыку!');
        if (message.guild.me.voice.channel !== message.member.voice.channel) {
            return message.channel.send("**Вы должны быть на одном канале с ботом!**");
          }
        const serverQueue = ops.queue.get(message.guild.id);
        if (!serverQueue) return message.channel.send('❌ **Ничего не играет на этом сервере**');
      try {
        serverQueue.connection.dispatcher.end();
        return message.channel.send('⏩ Пропущенно')
      } catch {
          serverQueue.connection.dispatcher.end();
          await channel.leave();
          return message.channel.send("**Что-то пошло не так!**")
      }
    }
};
module.exports = {
 
        name: 'join',
        aliases: ['joinvc'],
        category: 'music',
        description: 'Join The User\'s VC',
        usage: ' ',
        accessableby: 'everyone',
    run: async (bot, message, args, ops) => {
        const { channel } = message.member.voice;
        const serverQueue = ops.queue.get(message.guild.id);
      try {
        if (!channel) return message.channel.send(' Ты должен зайти в голосовой канал! ');
        if (!channel.permissionsFor(bot.user).has(['CONNECT', 'SPEAK', 'VIEW_CHANNEL'])) {
            return message.channel.send(`${message.author.username}, У меня нету прав что-бы зайти в голосовой`);
        };
        if (message.guild.me.voice.channel) return message.channel.send('Я уже в голосовом, используйте эту команду когда я не в голосовом');
      
        if (serverQueue || serverQueue.playing) {
          return message.channel.send("Я уже исполняю песню, повторите позже")
        }
        await channel.join();
        return message.channel.send("Я успешно зашел в голосовой")
      } catch {
          serverQueue.connection.dispatcher.end();
          return message.channel.send(" Что-то пошло не так. Пожалуйста, попытайтесь еще раз! ");
      }
    }
}
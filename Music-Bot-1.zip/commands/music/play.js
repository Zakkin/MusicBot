const { Util, MessageEmbed } = require('discord.js');
const { GOOGLE_API_KEY } = require('../../config');
const YouTube = require("simple-youtube-api");
const youtube = new YouTube(GOOGLE_API_KEY);
const Discord = require("discord.js");
const disbut = require('discord-buttons');
const { MessageActionRow, MessageButton } = require("discord-buttons");
const ytdl = require('ytdl-core');


module.exports = {

        name: 'play',
        description: 'Play command',
        aliases: ["p"],
        category: "music",
        usage: '[song (name | link)]',
        accessableby: "everyone",
    run: async (bot, message, args, ops) => {

   

   

        const { channel } = message.member.voice;
        if (!channel) return message.channel.send('Вы должны присоединиться к голосовому каналу, чтобы включить музыку!');

        if (!args[0]) return message.channel.send("Дай ссылку на ютуб или названия песни.")
        args = message.content.split(' ');
        const searchString = args.slice(1).join(' ');
        const url = args[1] ? args[1].replace(/<(.+)>/g, '$1') : '';


        const permissions = channel.permissionsFor(message.client.user);
        if (!permissions.has('CONNECT')) return message.channel.send('Отсутствует разрешение, у меня нет разрешения на подключение.');
        if (!permissions.has('SPEAK')) return message.channel.send('Отсутствует разрешение, у меня нет разрешения говорить.');

        let button1 = new MessageButton()
    .setLabel(`Пауза`)
    .setID(`pause`)
    .setStyle("red");

    let button2 = new MessageButton()
    .setLabel(`Возобновить`)
    .setID(`resume`)
    .setStyle("green");

    let button3 = new MessageButton()
    .setLabel(`Пропустить`)
    .setID(`skip`)
    .setStyle("green");

    let button4 = new MessageButton()
    .setLabel(`Пауза`)
    .setID(`dpause`)
    .setDisabled()
    .setStyle("grey");

     let button5 = new MessageButton()
    .setLabel(`Возобновить`)
    .setID(`dresume`)
    .setDisabled()
    .setStyle("grey");

     let button6 = new MessageButton()
    .setLabel(`Пропустить`)
    .setID(`dskip`)
    .setDisabled()
    .setStyle("grey");

    let button7 = new MessageButton()
    .setLabel(`Зациклить`)
    .setID(`loop`)
    .setStyle("blurple");

    let button8 = new MessageButton()
    .setLabel(`Зациклить`)
    .setID(`dloop`)
    .setDisabled()
    .setStyle("grey");

let rowss = new MessageActionRow()
    .addComponents(button4, button5, button6, button8);


    let row = new MessageActionRow()
    .addComponents(button1, button3, button7);

    let rows = new MessageActionRow()
    .addComponents(button2, button3);

        if (url.match(/^https?:\/\/(www.youtube.com|youtube.com)\/playlist(.*)$/)) {
            const playlist = await youtube.getPlaylist(url);
            const videos = await playlist.getVideos();

            for (const video of Object.values(videos)) {
                const video2 = await youtube.getVideoByID(video.id);
                await handleVideo(video2, message, channel, true);
            }
            return message.channel.send(`**Playlist \`${playlist.title}\` добавлен в очередь!**`);
        } else {
            try {
                var video = await youtube.getVideo(url);
            } catch (error) {
                try {
                    var videos = await youtube.searchVideos(searchString, 1);
                    var video = await youtube.getVideoByID(videos[0].id);
                } catch (err) {
                    console.error(err)
                    return message.channel.send(`Извиняюсь ${messahe.author.username}, я не смог найти песню.`)
                }
            }
            return handleVideo(video, message, channel);
        }
            async function handleVideo(video, message, channel, playlist = false) {
                const serverQueue = ops.queue.get(message.guild.id);
                const songInfo = await ytdl.getInfo(video.id);
                const song = {
                    id: video.id,
                    title: Util.escapeMarkdown(video.title),
                    url: `https://www.youtube.com/watch?v=${video.id}`,
                    thumbnail: `https://i.ytimg.com/vi/${video.id}/maxresdefault.jpg`,
                    duration: video.duration,
                    time: songInfo.videoDetails.lengthSeconds
                };

                let npmin = Math.floor(song.time / 60);
                let npsec = song.time - npmin * 60
                let np = `${npmin}:${npsec}`.split(' ')

                if (serverQueue) {
                    serverQueue.songs.push(song);
                    if (playlist) return undefined;
                    else {
                        const sembed = new MessageEmbed()
                            .setColor("GREEN")
                            .setTitle("Добавлено в очередь", message.author.displayAvatarURL())
                            .setThumbnail(song.thumbnail)
                            .setTimestamp()
                            .setDescription(`**Текущая песня:** [${song.title}](${song.url}) \n\n **Длительность песни:** ${np} минуты \n\n **Статус:** Публикуеться`)
                            .setFooter(`Добавлено пользователем: ${message.member.displayName}`);
                        message.channel.send(sembed)
                    }
                    return undefined;
                }

                const queueConstruct = {
                    textChannel: message.channel,
                    voiceChannel: channel,
                    connection: null,
                    songs: [],
                    volume: 6,
                    playing: true,
                    loop: false,
                };
                ops.queue.set(message.guild.id, queueConstruct);
                queueConstruct.songs.push(song);
                try {
                    const connection = await channel.join();
                    queueConstruct.connection = connection;
                    play(queueConstruct.songs[0]);
                } catch (error) {
                    console.error(`Я не мог присоединиться к голосовому каналу: ${error.message}`);
                    ops.queue.delete(message.guild.id);
                    await channel.leave();
                    return message.channel.send(`Я не мог присоединиться к голосовому каналу
: ${error.message}`);
                }
            };
            async function play(song) {
                const queue = ops.queue.get(message.guild.id);
                if (!song) {
                    queue.voiceChannel.leave();
                    ops.queue.delete(message.guild.id);
                    return;
                };

            
                
  const serverQueue = ops.queue.get(message.guild.id);
                let npmin = Math.floor(song.time / 60);
                let npsec = song.time - npmin * 60
                let np = `${npmin}:${npsec}`.split(' ')

                 

                const dispatcher = queue.connection.play(ytdl(song.url, { highWaterMark: 1 << 20, quality: "highestaudio" }))
                    .on('finish', () => {
                        if (queue.loop) {
                            queue.songs.push(queue.songs.shift());
                            return play(queue.songs[0]);
                        }
                        queue.songs.shift();
                        play(queue.songs[0]);
                    })
                    .on('error', error => console.error(error));
                dispatcher.setVolumeLogarithmic(queue.volume / 5);
  
  
        
                const embed = new MessageEmbed()
                    .setColor("GREEN")
                    .setTitle('Начал играть')
                    .setThumbnail(song.thumbnail)
                    .setTimestamp()
                    .setDescription(`**Текущая песня:** [${song.title}](${song.url}) \n\n **Длительность песни** ${np} минуты \n\n **Статус:** **Играет** \n\n *Только автор может пропускать и зацикливать песню*`)
                    .setFooter(`Добавлено пользователем: ${message.member.displayName} `, message.author.displayAvatarURL());

                    const embed3 = new MessageEmbed()
                    .setColor("GREEN")
                    .setTitle('Песня закончилась')
                    .setThumbnail(song.thumbnail)
                    .setTimestamp()
                    .setDescription(`**Title:** [${song.title}](${song.url}) \n\n **Длительность песни** ${np} минуты \n\n **Статус:** **Завершено** `)
                    .setFooter(`Добавлено пользователем: ${message.member.displayName} `, message.author.displayAvatarURL());

  



                    
                
                const MESSAGE = await queue.textChannel.send(embed, row);

    const filter = (button) => button.clicker.user.id !== bot.user.id

    const collector = MESSAGE.createButtonCollector(filter, { time: song.time > 0 ? song.time * 1000 : 600000 });

    collector.on('collect', async (b) => {
const { channel } = message.member.voice;
        
      const embed4 = new MessageEmbed()
                    .setColor("GREEN")
                    .setTitle('Начал играть')
                    .setThumbnail(song.thumbnail)
                    .setTimestamp()
                    .setDescription(`**Текущая песня:** [${song.title}](${song.url}) \n\n **Длительность песни** ${np} минуты \n\n **Статус:** Возобновлено пользователем ${b.clicker.member} \n\n Только автор может пропускать и зацикливать песню* `)
                    .setFooter(`Добавлено пользователем: ${message.member.displayName} `, message.author.displayAvatarURL());

      const embed2 = new MessageEmbed()
                    .setColor("#FF0000")
                    .setTitle('Музыка приостановлена')
                    .setThumbnail(song.thumbnail)
                    .setTimestamp()
                    .setDescription(`**Текущая песня:** [${song.title}](${song.url}) \n\n **Длительность песни:** ${np} minutes \n\n **Статус:** Приостановлено пользователем ${b.clicker.member} \n\n *Только автор может пропускать и зацикливать песню* `)
                    .setFooter(`Добавлено пользователем: ${message.member.displayName}`, message.author.displayAvatarURL());

                     const embed5 = new MessageEmbed()
                    .setColor("GREEN")
                    .setTitle('Начал играть')
                    .setThumbnail(song.thumbnail)
                    .setTimestamp()
                    .setDescription(`**Текущая песня:** [${song.title}](${song.url}) \n\n **Длительность песни** ${np} минуты \n\n **Статус:** Пропущено пользователем ${b.clicker.member} `)
                    .setFooter(`Добавлено пользователем: ${message.member.displayName} `, message.author.displayAvatarURL());

        if(b.id == "pause") {
          if (!channel) return await b.reply.send('Вы должны быть в голосовом канале', true);
          if (message.guild.me.voice.channel !== message.member.voice.channel) {
            return await b.reply.send('Вы должны быть подключены к моему голосовому каналу', true);
        }
  
           if (serverQueue && serverQueue.playing) {
            serverQueue.playing = false;
            serverQueue.connection.dispatcher.pause(true);
            MESSAGE.edit(embed2, rows);
            return await b.reply.send('Музыка приостановлена', true);
             
        }
  
    return await b.reply.send('Ничего не воспроизводится или песня уже поставлена ​​на паузу!', true);

   
  
        
        
            
        }
         if(b.id == "resume") {

           if (!channel) return await b.reply.send('Вы должны быть в голосовом канале', true);
           if (message.guild.me.voice.channel !== message.member.voice.channel) {
            return await b.reply.send('Вы должны быть подключены к моему голосовому каналу', true);
        }

           if (serverQueue && !serverQueue.playing) {
            serverQueue.playing = true;
            serverQueue.connection.dispatcher.resume();
                MESSAGE.edit(embed4, row);
            return await b.reply.send('Музыка возобновлена', true);
        }
      
    return await b.reply.send('Ничего не воспроизводится или песня уже возобновлена!', true);


  
        
        
            
            
        }

         if(b.id == "skip") {

           if (!channel) return await b.reply.send('Вы должны быть в голосовом канале', true);
if (message.guild.me.voice.channel !== message.member.voice.channel) {
            return await b.reply.send('Вы должны быть подключены к моему голосовому каналу', true);
        }

       if (b.clicker.id === message.author.id) {
        serverQueue.connection.dispatcher.end();
        MESSAGE.edit(embed5, rowss);
        return await b.reply.send('Пропущено!', true)
        
         }
         return await b.reply.send(`Только ${message.author.username} может пропускать. Пожалуйста, свяжитесь с ним, чтобы пропустить`, true)
      
       
            
            
        }
         if(b.id == "loop") {
if (!channel) return await b.reply.send('Вы должны быть в голосовом канале', true);
           
if (b.clicker.id === message.author.id ) {
            if (!serverQueue) return await b.reply.send('Сейчас ничего не играет.', true);
        if (message.guild.me.voice.channel !== message.member.voice.channel) {
            return await b.reply.send('Вы должны быть подключены к моему голосовому каналу', true);
        }
        if (!serverQueue.loop) {
            serverQueue.loop = true;
            return await b.reply.send('Цикл включен', true);
        } else {
            serverQueue.loop = false;
            return await b.reply.send('Цикл выключен', true);
        }
 }
         return await b.reply.send(`Только ${message.author.username} может зацикливать. Пожалуйста, свяжитесь с ним, чтобы пропустить`, true)


  
        
        
            
            
        }
      

    });

    collector.on('end', async (b) => {
  
        MESSAGE.edit(embed3, rowss)
    })
            };
             
     
    }
};